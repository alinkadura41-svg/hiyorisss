# A Little Date? ♡

This is the website project. Upload **the contents of this folder** to the root of your GitHub repository: `index.html`, `images/`, and `README.md`. Keep `index.html` beside the `images` folder so the pictures load.

The song player for “The Perfect Pair” by beabadoobee appears after clicking “Yes, absolutely!”. Internet is required; if embedding is blocked, use the fallback YouTube link shown on the page.

For GitHub Pages: Settings → Pages → Deploy from a branch → `main` → `/(root)` → Save.
