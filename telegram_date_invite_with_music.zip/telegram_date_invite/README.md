# A Little Date? ♡

A responsive pastel date-invitation website using your two images.

## Preview locally
Open `index.html` in a browser. Keep the `images` folder beside it.

## Publish with GitHub Pages
1. Create a public repository on GitHub, for example `little-date`.
2. Upload `index.html`, `README.md`, and the whole `images` folder.
3. Open **Settings → Pages**.
4. Select **Deploy from a branch**, branch **main**, folder **/(root)**, then **Save**.
5. Once published, GitHub will show the website link in the Pages section.
6. Send that link in Telegram.

The “Maybe..?” button tries to run away and changes its pleading message. The “The Plan” step includes Movie & Food, Just a Movie, Play Games Together, Call and Chat, Go for a Walk, and Surprise Me.
